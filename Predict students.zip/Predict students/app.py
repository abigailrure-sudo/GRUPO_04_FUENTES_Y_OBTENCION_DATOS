import streamlit as st
import pandas as pd

df = pd.read_csv("data/students_data_ucimlrepo.csv")
df['Target'] = df['Target'].apply(lambda x: 1 if 'dropout' in str(x).lower() else 0)

st.title("Exploración de abandono estudiantil")
st.dataframe(df)
