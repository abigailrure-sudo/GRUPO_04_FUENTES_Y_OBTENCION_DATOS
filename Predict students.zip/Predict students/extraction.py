from ucimlrepo import fetch_ucirepo 
import pandas as pd

def main():
    dataset = fetch_ucirepo(id=697)
    X = dataset.data.features
    y = dataset.data.targets
    df = pd.concat([X, y], axis=1)
    target_col = y.columns[0]
    df.rename(columns={target_col: 'Target'}, inplace=True)

    print("Primeras filas del dataset:")
    print(df.head())

    df.to_csv("data/students_data_ucimlrepo.csv", index=False)
    print("Datos guardados en data/students_data_ucimlrepo.csv")

if __name__ == "__main__":
    main()
