import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("data/students_data_ucimlrepo.csv")

# Convertir Target a binario
df['Target'] = df['Target'].apply(lambda x: 1 if 'dropout' in str(x).lower() else 0)

# Limpieza básica
df = df.dropna()

# Distribución del Target
sns.countplot(x='Target', data=df)
plt.title('Distribución abandono (Dropout)')
plt.show()
